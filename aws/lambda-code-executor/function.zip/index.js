var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// index.ts
var lambda_code_executor_exports = {};
__export(lambda_code_executor_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(lambda_code_executor_exports);
var import_child_process = require("child_process");
var import_fs = require("fs");
var import_path = require("path");
var import_crypto = require("crypto");
var handler = async (event) => {
  console.log(`[CodeExecutor] Received request for ${event.language}`);
  const { code, language } = event;
  if (!code || !language) {
    return {
      stdout: "",
      stderr: "Missing code or language parameter",
      exitCode: 1,
      error: "Invalid request"
    };
  }
  const execId = (0, import_crypto.randomUUID)();
  const tmpDir = `/tmp/${execId}`;
  try {
    (0, import_fs.mkdirSync)(tmpDir, { recursive: true });
    let filename;
    let cmd;
    switch (language) {
      case "python":
        filename = "script.py";
        cmd = ["python3", (0, import_path.join)(tmpDir, filename)];
        break;
      case "typescript":
      case "javascript":
      default:
        filename = "script.js";
        const wrappedCode = `
// Mock globals for testing
const test = (name, fn) => fn();
const describe = (name, fn) => fn();
const it = test;
const expect = (actual) => ({
  toBe: (expected) => {},
  toEqual: (expected) => {},
  toBeTruthy: () => {},
  toBeFalsy: () => {},
  toThrow: () => {},
  not: { toBe: () => {}, toThrow: () => {} }
});

// User code below
${code}
`;
        (0, import_fs.writeFileSync)((0, import_path.join)(tmpDir, filename), wrappedCode);
        cmd = ["node", (0, import_path.join)(tmpDir, filename)];
        break;
    }
    if (language === "python") {
      (0, import_fs.writeFileSync)((0, import_path.join)(tmpDir, filename), code);
    }
    const TIMEOUT_MS = 1e4;
    const result = await executeWithTimeout(cmd, TIMEOUT_MS);
    console.log(`[CodeExecutor] Execution completed with exit code ${result.exitCode}`);
    return result;
  } catch (error) {
    console.error(`[CodeExecutor] Error:`, error);
    return {
      stdout: "",
      stderr: error.message || "Unknown error",
      exitCode: 1,
      error: error.message
    };
  } finally {
    try {
      (0, import_fs.rmSync)(tmpDir, { recursive: true, force: true });
    } catch (e) {
    }
  }
};
async function executeWithTimeout(cmd, timeoutMs) {
  return new Promise((resolve) => {
    let stdout = "";
    let stderr = "";
    let killed = false;
    const proc = (0, import_child_process.spawn)(cmd[0], cmd.slice(1), {
      timeout: timeoutMs,
      killSignal: "SIGKILL"
    });
    const timer = setTimeout(() => {
      killed = true;
      proc.kill("SIGKILL");
    }, timeoutMs);
    proc.stdout?.on("data", (data) => {
      stdout += data.toString();
    });
    proc.stderr?.on("data", (data) => {
      stderr += data.toString();
    });
    proc.on("close", (code) => {
      clearTimeout(timer);
      if (killed) {
        resolve({
          stdout: stdout.slice(0, 5e3),
          stderr: "Execution timeout - code took too long",
          exitCode: 124,
          error: "Timeout"
        });
      } else {
        resolve({
          stdout: stdout.slice(0, 1e4),
          // Limit output size
          stderr: stderr.slice(0, 5e3),
          exitCode: code ?? 1
        });
      }
    });
    proc.on("error", (err) => {
      clearTimeout(timer);
      resolve({
        stdout: "",
        stderr: err.message,
        exitCode: 1,
        error: err.message
      });
    });
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
